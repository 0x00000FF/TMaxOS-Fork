#!/usr/bin/perl
# this is just a simple test script for use in the convmv test suite and not
# made for general use

$/="\0\0\n";
while (<>) {
	s/\0$//;
	my @arr = split ("\0\n", $_);
	my $options = "";
	my $cmd = "";
	for (shift(@arr)) {
		if    (/^rename$/) { $cmd = "mv"; }
		elsif (/^unlink$/) { $cmd = "rm"; }
		elsif (/^symlink$/) { $cmd = "ln -s"; }
		else { print "unimplemented function: $_"; }
	}
	for (@arr) {
		$options .= " \"$_\"";
	}
	print "$cmd$options\n";
	system("$cmd$options");
}
